# Space Shooter

A Pygame space shooter that can be played locally or packaged for modern browsers with Pygbag and WebAssembly.

## Controls

- Click the start screen to begin.
- Move with **W**, **A**, **S**, and **D**.
- Hold **Space** to fire.
- Click the game canvas first if the browser has not focused keyboard input.

Survive enemy waves, avoid enemy ships and lasers, and keep your health and lives. Each cleared wave advances the level.

## Run locally

Use Python 3.11 and install the dependencies:

```sh
python -m pip install -r requirements.txt
python main.py
```

## Test the browser build locally

Build the browser files, repair Pygbag 0.9.3's broken BrowserFS URL, and serve them locally:

```sh
python -m pygbag --build --app_name "Space Shooter" --title "Space Shooter" --package "space_shooter" .
python .github/scripts/patch_pygbag_output.py
python -m http.server 8000 --directory build/web
```

Open <http://localhost:8000> in a modern browser and click the game canvas to start and focus it. Pygbag writes the browser site to `build/web/`.

## Deploy to GitHub Pages

The workflow in `.github/workflows/pygbag.yml` builds the Pygbag site and deploys its static output with GitHub Pages Actions.

1. Commit and push the project files and workflow to the repository's `main` branch.
2. In the repository, open **Settings > Pages** and set **Build and deployment > Source** to **GitHub Actions**.
3. Open **Actions**, enable workflows if prompted, and run **Build and deploy Space Shooter** with **Run workflow** if a push has not already started it.
4. Wait for the build and deploy jobs to succeed. Later pushes to `main` deploy automatically.

The expected project-site URL is <https://RehanMohammed2609.github.io/Space-shooter/>. GitHub Pages must be available for the repository and account plan. A public site requires the repository to be public on plans that do not support Pages from private repositories.
